function [predicted_class,train_Time,output_struct]=Proj_NonL_LSTWSVM(A_test,A,FunPara)
%% A is testing data, B is training data, FunPara are the parameters
c1=FunPara.c1;
c2=c1;
c3=FunPara.c3;
c4=c3;
c0=FunPara.c0;
ir=FunPara.ir;
kerfPara = FunPara.kerfPara;
eps=1e-4;
[m,n]=size(A);[m_test,n_test]=size(A_test);
x0=A(:,1:n-1);y0=A(:,n);
xtest0=A_test(:,1:n_test-1);ytest0=A_test(:,n_test);
Cf=[x0 y0];
tic
C=nufuzz2(Cf,c0,ir);
%%
Amem=C(C(:,end-1)==1,end);
Bmem = C(C(:,end-1)~=1,end);
C=C(:,1:end-1);
A=C(C(:,end)==1,1:end-1);
B=C(C(:,end)~=1,1:end-1);
C=[A;B];

m1=size(A,1);m2=size(B,1);m3=size(C,1);
e1=ones(m1,1);e2=ones(m2,1);


K1=kernelfun(A,kerfPara,C);
K2=kernelfun(B,kerfPara,C);


center1=1/m1*sum(K1(:,:));
center2=1/m2*sum(K2(:,:));
M1=(K1(1,:)-center1)'*(K1(1,:)-center1);
M2=(K2(1,:)-center2)'*(K2(1,:)-center2);
for i=2:m1
    M1=M1+(K1(i,:)-center1)'*(K1(i,:)-center1);
end
for i=2:m2
    M2=M2+(K2(i,:)-center2)'*(K2(i,:)-center2);
end


S1=diag(Amem);
S2=diag(Bmem);
H=[K1 e1];%[A e1]

G=[S2*K2 S2*e2];%T'T
M1=[M1,zeros(size(M1,1),1);zeros(1,size(M1,1)),1]; % M1 is symmetric
I1=speye(m+1);

u1=-((1/c1)*M1+(1/c1)*(H'*H)+(c3/c1)*I1+G'*G)\G'*S2*e2;

R=[K2 e2];%[A e1]
T=[K1 e1];
M2=[M2,zeros(size(M2,1),1);zeros(1,size(M2,1)),1]; % M2 is symmetric

u2=((1/c2)*M2+(1/c2)*(R'*R)+(c4/c2)*I1+T'*T)\T'*S1*e1;

train_Time=toc;
%---------------Testing---------------
no_test=size(xtest0,1);
K=kernelfun(xtest0,kerfPara,C);
K1=[K-repmat(center1,size(K,1),1) ones(no_test,1)];
K2=[K-repmat(center2,size(K,1),1) ones(no_test,1)];
preY1=K1*u1/norm(u1(1:size(u1,1)-1,:));
preY2=K2*u2/norm(u2(1:size(u2,1)-1,:));
predicted_class=[];
for i=1:no_test
    if abs(preY1(i))< abs(preY2(i))
        predicted_class=[predicted_class;1];
    else
        predicted_class=[predicted_class;-1];
    end
    
end
%%%%%%%Imbalance accuracy
no_test=m_test;
classifier=predicted_class;
obs1=ytest0;
match = 0.;
match1=0;
% classifier = classifier';
% obs1 = test_data(:,no_col);
posval=0;
negval=0;
%[test_size,n] = size(classifier);
for i = 1:no_test
    if(obs1(i)==1)
        if(classifier(i) == obs1(i))
            match = match+1;
        end
        posval=posval+1;
    elseif(obs1(i)==-1)
        if(classifier(i) ~= obs1(i))
            match1 = match1+1;
        end
        negval=negval+1;
    end
end
if(posval~=0)
    a_pos=(match/posval);
else
    a_pos=0;
end

if(negval~=0)
    am_neg=(match1/negval);
else
    am_neg=0;
end

AUC=(1+a_pos-am_neg)/2

accuracy=AUC*100;
st = dbstack;
output_struct.function_name= st.name;
end
